# FAB v2 public: real Qianwen API trial

Authentication: user-provided API Key. Codex login used: false.
Research: hosted web_search/web_extractor/code_interpreter; local submit_answer function writes actual artifacts.
Scores: two-model diagnostic grading on public cases, not an official FAB leaderboard or three-judge jury.

| Target | Case | Qwen Judge | GLM Judge | Diagnostic mean | Target seconds |
| --- | --- | ---: | ---: | ---: | ---: |
| qwen3.8-max-0902 | fabv2-public-003 | 1.0000 | 1.0000* | 1.0000 | 1480.89 |
| qwen3.8-max-0902 | fabv2-public-004 | 1.0000 | 1.0000* | 1.0000 | 767.52 |
| glm-5.3 | fabv2-public-003 | 1.0000 | 1.0000* | 1.0000 | 354.48 |
| glm-5.3 | fabv2-public-004 | 1.0000 | 1.0000* | 1.0000 | 263.20 |

* GLM originally returned valid verdicts inside a Markdown JSON fence; the first parser marked them unscored.
The starred scores are offline recomputation from those same recorded responses after the parser fix. No new model calls; original records remain unchanged.
See offline-recovery.json for raw response hashes, original errors, parser/build identity and criterion-level verdicts.

| Target | Case | Input tokens | Cached input | Output | Reasoning | Search / fetch / code |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| qwen3.8-max-0902 | fabv2-public-003 | 1462718 | 1295744 | 48198 | 15397 | 4 / 8 / 70 |
| qwen3.8-max-0902 | fabv2-public-004 | 363131 | 279552 | 21773 | 10167 | 8 / 12 / 6 |
| glm-5.3 | fabv2-public-003 | 766442 | 719872 | 18380 | 9198 | 2 / 4 / 36 |
| glm-5.3 | fabv2-public-004 | 216017 | 185856 | 14218 | 7904 | 5 / 3 / 7 |

Token counters sum provider-reported research steps and continuations, not unique context length.
Cached input is a subset of input, reasoning a subset of output. This table excludes Judges and readiness probes; their actual usage is in the raw records.
Tool event counts describe provider-returned events; underlying queries may differ.
Input/output/cache/reasoning counters are provider-reported. Costs and cloud CPU/memory are unknown unless reported.
Every failure/unscored item remains in the report. No answer or rubric was edited to improve a score.
