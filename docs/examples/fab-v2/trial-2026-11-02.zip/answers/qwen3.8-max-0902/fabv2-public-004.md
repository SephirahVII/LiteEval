# CRWD vs. PANW — 2‑Year Total Revenue CAGR, FY2023 → FY2025

**Answer: CrowdStrike (NASDAQ: CRWD) had the higher 2‑year revenue CAGR — 32.82% vs. Palo Alto Networks' 15.67% — a gap of ≈ 1,715 basis points (17.15 percentage points).**

---

## 1. Date interpretation (important — the two fiscal calendars do not align)

The question says "FY 2023 to FY 2025." I interpreted this as **each company's own labeled fiscal years**, exactly two fiscal‑year steps apart (so the CAGR exponent is 1/2 for both). No calendarization or period shifting was applied.

| Company | Fiscal year end | "FY2023" covers | "FY2025" covers |
|---|---|---|---|
| CrowdStrike (CRWD) | January 31 | Feb 1, 2022 – **Jan 31, 2023** | Feb 1, 2024 – **Jan 31, 2025** |
| Palo Alto Networks (PANW) | July 31 | Aug 1, 2022 – **Jul 31, 2023** | Aug 1, 2024 – **Jul 31, 2025** |

**Caveat:** the two measurement windows are offset by ~6 months (CRWD's FY2025 maps roughly to calendar 2024; PANW's FY2025 maps roughly to calendar 2025). Both windows are nonetheless exactly 24 months of their own fiscal calendar. Section 5 tests whether the offset changes the conclusion (it does not).

---

## 2. Primary-source revenue inputs (GAAP total revenue, as reported)

| Company | Fiscal year (period end) | Total revenue | Source (as originally reported) | Also appears as comparative in |
|---|---|---|---|---|
| CRWD | FY2023 (Jan 31, 2023) | **$2,241,236 thousand** ($2,241.2M) | FY2023 Form 10‑K, Consol. Statements of Operations (acc. 0001535527‑23‑000008; auditor report dated Mar 8, 2023; EDGAR filing date Mar 9, 2023) | FY2025 10‑K (unchanged: $2,241,236K) |
| CRWD | FY2025 (Jan 31, 2025) | **$3,953,624 thousand** ($3,953.6M) | FY2025 Form 10‑K, filed 2025‑03‑10 (acc. 0001535527‑25‑000009) | FY2026 10‑K (unchanged: $3,953,624K) |
| PANW | FY2023 (Jul 31, 2023) | **$6,892.7 million** | FY2023 Form 10‑K, filed 2023‑09‑01 (acc. 0001327567‑23‑000024) | FY2025 10‑K (unchanged: $6,892.7M) |
| PANW | FY2025 (Jul 31, 2025) | **$9,221.5 million** | FY2025 Form 10‑K, filed 2025‑08‑29 (acc. 0001327567‑25‑000027); also Q4/FY2025 earnings release (8‑K Ex‑99.1) | — |

**Verification of the underlying components (PANW, from Note 2 – Revenue in the FY2025 10‑K, $M):**

| | FY2025 | FY2024 | FY2023 |
|---|---|---|---|
| Product | 1,801.9 | 1,603.3 | 1,578.4 |
| Subscription | 4,974.4 | 4,188.5 | 3,335.4 |
| Support | 2,445.2 | 2,235.7 | 1,978.9 |
| **Total revenue** | **9,221.5** | **8,027.5** | **6,892.7** |

**Verification of the underlying components (CRWD, FY2025 10‑K MD&A, $000):**

| | FY2025 | FY2024 | FY2023 |
|---|---|---|---|
| Subscription | 3,761,480 | 2,870,557 | 2,111,660 |
| Professional services | 192,144 | 184,998 | 129,576 |
| **Total revenue** | **3,953,624** | **3,055,555** | **2,241,236** |

Supporting MD&A quotes:
- CRWD FY2025 10‑K: *"Total revenue increased by $898.1 million, or 29%, in fiscal 2025, compared to fiscal 2024."*
- PANW FY2025 10‑K: *"For fiscal 2025 and 2024, total revenue was $9.2 billion and $8.0 billion, respectively, representing year-over-year growth of 14.9%."*
- PANW FY2023 10‑K: *"For fiscal 2023 and 2022, total revenue was $6.9 billion and $5.5 billion, respectively, representing year-over-year growth of 25.3%."*
- CRWD FY2023 10‑K: *"Total revenue increased by $789.6 million, or 54%, in fiscal 2023, compared to fiscal 2022."*

---

## 3. Calculations (2‑year CAGR = (End/Begin)^(1/2) − 1)

**CrowdStrike**
```
Multiple = 3,953,624 / 2,241,236          = 1.76403734
CAGR     = 1.76403734^(1/2) − 1           = 1.32817068 − 1 = 0.32817068
         = 32.8171%  =  3,281.7 bps
Cumulative 2-yr growth = +76.40%
```

**Palo Alto Networks**
```
Multiple = 9,221.5 / 6,892.7               = 1.33786470
CAGR     = 1.33786470^(1/2) − 1            = 1.15666101 − 1 = 0.15666101
         = 15.6661%  =  1,566.6 bps
Cumulative 2-yr growth = +33.79%
```

**Spread**
```
Δ = 3,281.7 bps − 1,566.6 bps = 1,715.1 bps  ≈ 1,715 bps (17.15 percentage points)
```

**Cross-check via annual YoY rates (geometric mean, must equal the CAGR):**
- CRWD: FY24 YoY = 3,055,555/2,241,236 − 1 = +36.33%; FY25 YoY = 3,953,624/3,055,555 − 1 = +29.39% → √(1.3633 × 1.2939) − 1 = **32.817%** ✓
- PANW: FY24 YoY = 8,027.5/6,892.7 − 1 = +16.46%; FY25 YoY = 9,221.5/8,027.5 − 1 = +14.87% → √(1.1646 × 1.1487) − 1 = **15.666%** ✓

---

## 4. Result

| Metric (FY2023 → FY2025) | CRWD | PANW | Winner |
|---|---|---|---|
| Beginning total revenue | $2,241.2M (FYE 1/31/2023) | $6,892.7M (FYE 7/31/2023) | — |
| Ending total revenue | $3,953.6M (FYE 1/31/2025) | $9,221.5M (FYE 7/31/2025) | — |
| 2‑yr revenue CAGR | **32.82%** (3,281.7 bps) | **15.67%** (1,566.6 bps) | **CRWD** |
| Advantage | — | — | **≈ 1,715 bps** |

**CrowdStrike achieved the higher 2‑year revenue CAGR, exceeding Palo Alto Networks by approximately 1,715 basis points** (32.82% vs. 15.67%).

---

## 5. Robustness and sensitivity

**(a) Rounding of inputs.** Using CRWD figures rounded to $2,241.2M/$3,953.6M instead of the as‑filed thousands gives 3,281.8 bps (vs. 3,281.7). Using PANW FY2023 = $6,893.0M (the figure some data aggregators show, vs. $6,892.7M in the 10‑K) gives 1,566.4 bps. Resulting spread range: **1,715.1 – 1,715.3 bps**. Any answer in the ~1,710–1,720 bps band is consistent with the filings.

**(b) Six‑month fiscal‑calendar offset.** Shifting CrowdStrike one year later to FY2024 → FY2026 (Jan 31, 2024 → Jan 31, 2026: $3,055,555K → $4,812,005K, per the FY2025 and FY2026 10‑Ks) yields a 2‑yr CAGR of **25.49%**, still ~**983 bps** above PANW's FY2023→FY2025 CAGR. **The ranking (CRWD > PANW) is unchanged under the alternative alignment.**

**(c) No revenue restatement.** Neither company's *revenue* line for the FY2023 base year differs between its original FY2023 10‑K and the comparative column of its FY2025 10‑K (CRWD $2,241,236K both times; PANW $6,892.7M both times). One disclosure note: CrowdStrike's FY2026 10‑K (filed March 2026) states the company *"revised its fiscal 2025 and 2024 financial results to correct for an immaterial error discovered during the fourth quarter of fiscal 2026."* Total revenue for FY2025 is nonetheless reported unchanged at **$3,953,624K** in that filing's MD&A comparison table, so the figures used above are unaffected.

**(d) Later fiscal years now exist.** As of the research date (November 2, 2026), CRWD FY2026 (ended 1/31/2026; revenue $4,812,005K) and PANW FY2026 (ended 7/31/2026; revenue ~$11.5B) have both been reported. Per the question's explicit instruction, I did **not** substitute the latest fiscal year — the computation above is strictly FY2023 → FY2025.

---

## 6. Uncertainty / limitations

- All figures are **GAAP total revenue** as reported on the face of the consolidated statements of operations in each company's own Form 10‑K. No non‑GAAP or "next‑generation ARR" measures were used.
- The comparison mixes two different fiscal calendars (Jan‑year‑end vs. Jul‑year‑end); this is a structural limitation of the question as posed, quantified in 5(b).
- One automated extraction of the CRWD FY2026 10‑K returned an internally inconsistent FY2024 revenue value ($4,077,995K), which contradicts that filing's own change table and the FY2025 10‑K ($3,055,555K). I discarded it and relied on the FY2025 10‑K for FY2024. This does not affect any number used in the final calculation, since FY2024 is not an endpoint.
- Basis‑point results are rounded to 1 decimal; the headline figure rounds to **≈1,715 bps**.

---

## 7. Sources (URLs and reporting periods)

1. **CrowdStrike Holdings, Inc. — Form 10‑K for FY ended January 31, 2025** (filed 2025‑03‑10; accession 0001535527‑25‑000009). Total revenue FY2025 $3,953,624K; FY2024 $3,055,555K; FY2023 $2,241,236K. https://www.sec.gov/Archives/edgar/data/1535527/000153552725000009/crwd-20250131.htm
2. Filing detail for the above (Period of Report 2025‑01‑31, Filing Date 2025‑03‑10). https://www.sec.gov/Archives/edgar/data/1535527/000153552725000009/0001535527-25-000009-index.htm
3. **CrowdStrike Holdings, Inc. — Form 10‑K for FY ended January 31, 2023** (accession 0001535527‑23‑000008; auditor report dated Mar 8, 2023; EDGAR filing date Mar 9, 2023). Total revenue FY2023 $2,241,236K; FY2022 $1,451,594K. https://www.sec.gov/Archives/edgar/data/1535527/000153552723000008/crwd-20230131.htm
4. CrowdStrike IR filing record for the FY2023 10‑K (Filing Date Mar 9, 2023; Document Date Jan 31, 2023). https://ir.crowdstrike.com/sec-filings/sec-filing/10-k/0001535527-23-000008
5. **Palo Alto Networks, Inc. — Form 10‑K for FY ended July 31, 2025** (filed 2025‑08‑29; accession 0001327567‑25‑000027). Total revenue FY2025 $9,221.5M; FY2024 $8,027.5M; FY2023 $6,892.7M. https://www.sec.gov/Archives/edgar/data/1327567/000132756725000027/panw-20250731.htm
6. **Palo Alto Networks, Inc. — Form 10‑K for FY ended July 31, 2023** (filed 2023‑09‑01; accession 0001327567‑23‑000024). Total revenue FY2023 $6,892.7M; FY2022 $5,501.5M; FY2021 $4,256.1M. https://www.sec.gov/Archives/edgar/data/1327567/000132756723000024/panw-20230731.htm
7. Palo Alto Networks IR copy of the FY2023 Form 10‑K ("filed 09/01/2023"). https://investors.paloaltonetworks.com/static-files/3cceefe0-d00f-40d9-8040-4639de6d113c
8. **Palo Alto Networks — Q4 & FY2025 earnings release** (Fiscal year ended July 31, 2025): consolidated statements of operations show FY2025 total revenue $9,221.5M vs. FY2024 $8,027.5M. https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-reports-fiscal-fourth-quarter-and-fiscal-year-2025-financial-results
9. **CrowdStrike — Q4 & FY2025 earnings release** (Fiscal year ended January 31, 2025): total revenue $3.95B, +29%. https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025
10. **CrowdStrike Holdings, Inc. — Form 10‑K for FY ended January 31, 2026** (filed March 2026). Used only for robustness check 5(b) and the immaterial‑revision note in 5(c): FY2026 revenue $4,812,005K; FY2025 $3,953,624K. https://www.sec.gov/Archives/edgar/data/1535527/000153552726000010/crwd-20260131.htm
