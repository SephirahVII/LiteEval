# Competitive Landscape Disclosures: Electronic Arts (NASDAQ: EA) vs. Take-Two Interactive (NASDAQ: TTWO)

**Basis of analysis (date interpretation):** The question does not specify a fiscal year, so I used each company's most recent annual report on Form 10-K as of November 2, 2026 — for both companies this is the **fiscal year ended March 31, 2026 (FY2026)**:
- **EA:** Form 10-K filed with the SEC on **May 11, 2026** (accession 0001628280-26-033617). A Form 10-K/A filed July 28, 2026 amends only Part III (Items 10–14) and does not change the Business/Competition disclosure.
- **TTWO:** Form 10-K filed with the SEC on **May 22, 2026** (accepted May 21, 2026 after 5:30 p.m. ET; accession 0001628280-26-037434).

I also verified the FY2025 10-Ks (filed May 2025) to confirm the disclosure pattern is consistent across years.

---

## 1. Electronic Arts (EA) — FY2026 Form 10-K

### Item 1 (Business), "Competition" section
EA's competition disclosure is **generic and does not name a single competitor**. EA identifies its competitors only by category:

- **Direct (interactive entertainment) competitors, by category only:**
  - "companies that focus on developing products and services available on consoles, PCs and/or mobile devices";
  - "large, diversified companies that have strengthened their interactive entertainment capabilities," whose "greater financial and other resources may provide larger budgets to develop and market tools, technologies, products and services that gain consumer success and shift player time and engagement away from our products and services";
  - "new entrants … [as] advances in technology and artificial intelligence have lowered the barriers to creating new games";
  - competition "for the right to license certain intellectual property included in our products."

- **Non-interactive entertainment competitors:** "More broadly, we compete against providers of different sources of entertainment, such as **movies, television, social media, online casual entertainment and music** that our players could enjoy in their free time."

- **Competitive factors disclosed:** ability to attract creative and technical talent, game quality and ease of use, innovation, compatibility with consoles/other distribution channels, brand recognition, reputation, reliability, security, creativity, price, marketing, and quality of customer service.

### Item 1A (Risk Factors) — "Competition in our business is intense"
Again **no competitors are named**: "Our competitors range from established interactive entertainment companies to emerging start-ups… we compete with large, diversified companies that have strengthened their interactive entertainment capabilities… We also expect new competitors to continue to emerge throughout the world… products or services of our direct competitors or other entertainment companies have shifted consumer spending or engagement from our products and services…" A parallel "Increased Competition" discussion in MD&A repeats this unnamed, category-based framing.

**Note:** In EA's FY2026 10-K, companies like Sony, Microsoft, Apple, and Google appear only as console manufacturers/distribution platforms (customers), Tencent/Nexon/Garena as commercial partners, and Disney as a licensor of Star Wars rights — none is identified as a competitor.

---

## 2. Take-Two Interactive (TTWO) — FY2026 Form 10-K

### Item 1 (Business), "Competition" section
TTWO organizes its competition disclosure into **four explicit categories and names specific competitors**:

1. **Other interactive entertainment companies** (ranging "from very small with limited resources to very large with greater financial, marketing, technical, and other resources than ours"). "**Examples of our competitors include Electronic Arts, Embracer Group, Epic Games, Playrix, Playtika, Roblox, Savvy Games, Tencent, and Ubisoft.** We also expect new competitors to enter the market…" *(In FY2025 the list was eight names — Electronic Arts Inc., Embracer Group AB, Playrix, Playtika, Roblox, Savvy Games, Tencent, and Ubisoft Entertainment S.A.; Epic Games was added in FY2026.)*
2. "**Sony, Microsoft, and Nintendo** for the sale of interactive entertainment software. Each of these competitors is a large developer and marketer of software for their own platforms and has the financial resources to withstand significant price competition and to implement extensive advertising campaigns."
3. "**Other software, hardware, entertainment, and media** for limited retail shelf space and promotional resources" — with competition for shelf space, "whether physical or virtual," described as intense.
4. **Non-interactive entertainment competitors:** "**Other forms of entertainment such as motion pictures, television, social networking, online applications, short-form video, and other forms of entertainment, which may be less expensive or provide other advantages to consumers.**"

### Item 1A (Risk Factors) — "The interactive entertainment software industry is highly competitive"
Additional named detail:
- "We compete for both **licenses to properties and the sale of interactive entertainment software with Sony and Microsoft**, each of which is a large developer and marketer of software for its own platforms."
- "We also compete with **game publishers, such as Electronic Arts, Embracer Group, Epic Games, Microsoft, Nintendo, Playrix, Playtika, Roblox, Savvy Games, Sony, Tencent, and Ubisoft**."
- "We also face competition from **online game developers and distributors who have primarily focused on specific international markets** and with high-profile companies with significant online presences with new and expanded mobile gaming offerings, such as **Apple, Google, and Microsoft**."
- Larger, well-funded **technology companies** "pursuing and strengthening their interactive entertainment capabilities"; internationally, local competitors with greater local brand recognition; competitors imitating hit games, "including by using AI to do so"; a "vast number of small companies and individuals" creating mobile/online games with limited resources (mobile/social free-to-play risk factor).
- Non-interactive entertainment: "Our titles also compete with **other forms of entertainment, such as social media, in addition to motion pictures, television, short-form video, and audio and video products** featuring similar themes, online computer programs and other entertainment…"
- Other Item 1A risk factors state that the **Apple App Store, the Google Play Store, and Facebook are "also our direct competitors"** (while being exclusive distribution channels for its mobile content), and that in its advertising business TTWO competes with "many large companies, such as **Amazon, Facebook and Google**."

---

## 3. Which company provides more detailed competitive-landscape disclosure?

**Take-Two Interactive (TTWO) provides substantially more detailed disclosure.**

| Dimension | EA (FY2026 10-K) | TTWO (FY2026 10-K) |
|---|---|---|
| Named direct competitors | **None** | **9 publisher competitors named in Item 1** (Electronic Arts, Embracer Group, Epic Games, Playrix, Playtika, Roblox, Savvy Games, Tencent, Ubisoft); plus Sony, Microsoft, Nintendo as platform-based competitors; Apple, Google, Microsoft (mobile/online); Amazon, Facebook, Google (advertising) in risk factors |
| Structure | Two short paragraphs of category-level description | Four enumerated competitive categories, plus a dedicated risk factor and mobile/social free-to-play competition risk |
| Non-interactive entertainment competitors | Yes — movies, television, social media, online casual entertainment, music | Yes — motion pictures, television, social networking, online applications, short-form video, audio/video products |
| Competitive factors | Enumerated list (talent, quality, innovation, compatibility, brand, price, marketing, customer service) | Enumerated list (innovation, features, playability, product quality, brand recognition, platform compatibility, distribution access, price, marketing, customer service) |
| Where disclosed | Item 1 (brief), Item 1A, MD&A | Item 1, Item 1A (two-plus risk factors), including platform/distribution and advertising competition |

EA describes the competitive environment only in general terms (dedicated interactive-entertainment companies, large diversified companies strengthening gaming capabilities, and new AI-enabled entrants) and never identifies a competitor by name in its 10-K — a pattern consistent at least from FY2025 through FY2026. TTWO, by contrast, names its peers and platform rivals explicitly, describes the basis of competition in each category, and flags non-interactive entertainment (film, TV, social networking, short-form video) as competition for consumer time and spending.

**Uncertainty/limitations:** Both filings list competitors as "examples" and are not exhaustive; EA's silence on names should not be read as an absence of competitors (EA competes with the same peer set in practice, as evidenced by TTWO naming EA as a competitor). No quantitative market-share or competitive-positioning data is disclosed by either company. EA's 10-K/A (July 28, 2026) amends only Part III and does not affect the competition disclosure cited here.

---

## Sources and reporting periods
- **EA Form 10-K, fiscal year ended March 31, 2026**, filed May 11, 2026 — Part I, Item 1 ("Competition"), Item 1A ("Competition in our business is intense"), Part II MD&A ("Increased Competition"). URL: https://www.sec.gov/Archives/edgar/data/712515/000162828026033617/ea-20260331.htm
- **TTWO Form 10-K, fiscal year ended March 31, 2026**, filed May 22, 2026 — Part I, Item 1 ("Competition"), Item 1A ("The interactive entertainment software industry is highly competitive"; platform-distribution and advertising risk factors). URL: https://www.sec.gov/Archives/edgar/data/946581/000162828026037434/ttwo-20260331.htm
- **EA Form 10-K/A (Amendment No. 1)**, fiscal year ended March 31, 2026, filed July 28, 2026 (Part III only): https://www.sec.gov/Archives/edgar/data/712515/000130817926000382/ea2026-10ka.htm
- **EA Form 10-K, fiscal year ended March 31, 2025**, filed May 13, 2025 (consistency check): https://www.sec.gov/Archives/edgar/data/712515/000071251525000022/ea-20250331.htm
- **TTWO Form 10-K, fiscal year ended March 31, 2025**, filed May 20, 2025 (consistency check; named-competitor list comparison): https://www.sec.gov/Archives/edgar/data/946581/000162828025026694/ttwo-20250331.htm
