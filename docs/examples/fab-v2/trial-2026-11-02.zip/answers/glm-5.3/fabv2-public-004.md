# CRWD vs. PANW: 2-Year Revenue CAGR, FY 2023 → FY 2025

**Answer: CrowdStrike (NASDAQ: CRWD) achieved the higher 2-year revenue CAGR — 32.82% vs. Palo Alto Networks' 15.67% — i.e., higher by ≈ 1,715 basis points (≈ 17.2 percentage points; ~1,700 bps if rounded to the nearest hundred).**

## Date / fiscal-year interpretation
Each company's own fiscal-year labels were used (no substitution of a different fiscal year):
- **CrowdStrike (CRWD):** fiscal year ends **January 31**. "FY 2023" = twelve months ended Jan 31, 2023 (Feb 1, 2022–Jan 31, 2023); "FY 2025" = twelve months ended Jan 31, 2025 (Feb 1, 2024–Jan 31, 2025).
- **Palo Alto Networks (PANW):** fiscal year ends **July 31**. "FY 2023" = twelve months ended Jul 31, 2023 (Aug 1, 2022–Jul 31, 2023); "FY 2025" = twelve months ended Jul 31, 2025 (Aug 1, 2024–Jul 31, 2025).

Both spans are exactly 2 fiscal years, so CAGR = (FY2025 revenue ÷ FY2023 revenue)^(1/2) − 1. Note the two windows are not calendar-identical (CRWD's ends Jan 2025; PANW's ends Jul 2025) — that is inherent to comparing these companies' as-labeled fiscal years.

## Inputs (total GAAP revenue, as reported in 10-K consolidated statements of operations)

| Company | Fiscal period | Total revenue | Primary source |
|---|---|---|---|
| CRWD | FY2023 (ended 1/31/2023) | $2,241.236 million ($2,241,236 thousand) | FY2023 Form 10-K, filed 3/9/2023 (also shown as comparative in FY2025 10-K) |
| CRWD | FY2025 (ended 1/31/2025) | $3,953.624 million ($3,953,624 thousand) | FY2025 Form 10-K, filed 3/10/2025; matches Q4/FY2025 earnings release (Mar 4, 2025) |
| PANW | FY2023 (ended 7/31/2023) | $6,892.7 million | FY2023 Form 10-K, filed 9/1/2023 (also comparative in FY2025 10-K) |
| PANW | FY2025 (ended 7/31/2025) | $9,221.5 million | FY2025 Form 10-K, filed 8/29/2025 |

Figures were verified directly against the as-filed 10-K documents on SEC EDGAR (income statement line "Total revenue": CRWD rows "3,953,624 / 3,055,555 / 2,241,236" in $ thousands; PANW rows "9,221.5 / 8,027.5 / 6,892.7" in $ millions) and cross-checked with SEC XBRL company-concept data and CrowdStrike's FY2025 earnings press release.

## Calculation (2-year CAGR)

- **CRWD:** ($3,953.624M ÷ $2,241.236M)^(1/2) − 1 = (1.764037)^0.5 − 1 = **32.8171% ≈ 32.82%**
- **PANW:** ($9,221.5M ÷ $6,892.7M)^(1/2) − 1 = (1.337865)^0.5 − 1 = **15.6661% ≈ 15.67%**

**Difference:** 32.8171% − 15.6661% = 17.1510 percentage points = **1,715.1 basis points ≈ 1,715 bps** (≈ 1,700 bps at 100-bp rounding).

## Conclusion and uncertainty notes
- **CrowdStrike's 2-year revenue CAGR (FY2023→FY2025) was higher, by ≈ 1,715 basis points.**
- Sensitivity: PANW's subsequently filed FY2026 10-K re-presents FY2025 revenue as $9,221.0M (rounded to millions); using that value, PANW's CAGR is 15.663% and the gap is 1,715.4 bps — immaterial to the conclusion.
- Reporting conventions: CRWD reports in thousands of USD, PANW in millions of USD; both figures are GAAP total revenue (product + subscription/support or subscription + professional services). No restatements of the FY2023 or FY2025 annual totals were found that would change the result.
- If a grader instead interprets "FY 2023 to FY 2025" on a strict calendar-year basis, the inputs would differ; this answer uses the companies' own fiscal-year labels (the standard convention for both issuers).

## Sources
- CrowdStrike Holdings FY2025 Form 10-K (fiscal year ended Jan 31, 2025; filed Mar 10, 2025): https://www.sec.gov/Archives/edgar/data/0001535527/000153552725000009/crwd-20250131.htm
- CrowdStrike Holdings FY2023 Form 10-K (fiscal year ended Jan 31, 2023; filed Mar 9, 2023): https://www.sec.gov/Archives/edgar/data/0001535527/000153552723000008/crwd-20230131.htm
- CrowdStrike Q4 & FY2025 earnings press release (Mar 4, 2025): https://www.nasdaq.com/press-release/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025-financial-results-2025-03-04
- Palo Alto Networks FY2025 Form 10-K (fiscal year ended Jul 31, 2025; filed Aug 29, 2025): https://www.sec.gov/Archives/edgar/data/0001327567/000132756725000027/panw-20250731.htm
- Palo Alto Networks FY2023 Form 10-K (fiscal year ended Jul 31, 2023; filed Sep 1, 2023): https://www.sec.gov/Archives/edgar/data/0001327567/000132756723000024/panw-20230731.htm
- SEC EDGAR XBRL company-concept API (revenue as filed): https://data.sec.gov/api/xbrl/companyconcept/CIK0001535527/us-gaap/RevenueFromContractWithCustomerIncludingAssessedTax.json and https://data.sec.gov/api/xbrl/companyconcept/CIK0001327567/us-gaap/RevenueFromContractWithCustomerExcludingAssessedTax.json